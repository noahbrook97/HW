Class Knight solves a knight’s open tour.
It creates a square board specified by user input and prints it out each time a knight moves. Knight solves the tour recursively by calling the function until the move equal to the board’s area is placed. It repeatedly calls the solve function for all the moves a knight can make until it finds and empty space.
